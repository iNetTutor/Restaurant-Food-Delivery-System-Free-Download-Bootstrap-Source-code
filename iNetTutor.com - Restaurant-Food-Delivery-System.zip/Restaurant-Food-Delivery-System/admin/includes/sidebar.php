        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" >
                <li><a href="index.php" class="ai-icon" aria-expanded="false">
						<i class="mdi mdi-view-dashboard"></i>
						<span class="nav-text">Dashboard</span>
					</a>
				</li>
                <li><a href="restaurant.php" class="ai-icon" aria-expanded="false">
						<i class="mdi mdi-office-building"></i>
						<span class="nav-text">Restaurant</span>
					</a>
				</li>
                <li><a href="food-list.php" class="ai-icon" aria-expanded="false">
						<i class="mdi mdi-food"></i>
						<span class="nav-text">Food List</span>
					</a>
				</li>
                <li><a href="driver.php" class="ai-icon" aria-expanded="false">
						<i class="mdi mdi-truck-delivery"></i>
						<span class="nav-text">Delivery Driver</span>
					</a>
				</li>
                <li><a href="feedback.php" class="ai-icon" aria-expanded="false">
						<i class="mdi mdi-comment-text-multiple-outline"></i>
						<span class="nav-text">Feedback & Reports</span>
					</a>
				</li>
                <li><a href="settings.php" class="ai-icon" aria-expanded="false">
						<i class="mdi mdi-cogs"></i>
						<span class="nav-text">System Settings</span>
					</a>
				</li>
                <li><a href="admin-user.php" class="ai-icon" aria-expanded="false">
						<i class="mdi mdi-nature-people"></i>
						<span class="nav-text">Admin Users</span>
					</a>
				</li>
                <li><a href="reports.php" class="ai-icon" aria-expanded="false">
						<i class="mdi mdi-chart-bar-stacked"></i>
						<span class="nav-text">Sales Report</span>
					</a>
				</li>
                </ul>
            
			</div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->
		