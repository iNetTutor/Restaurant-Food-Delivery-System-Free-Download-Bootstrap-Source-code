        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" >
                <li><a href="index.php" class="ai-icon" aria-expanded="false">
						<i class="mdi mdi-view-dashboard"></i>
						<span class="nav-text">Dashboard</span>
					</a>
				</li>
                <li><a href="order.php" class="ai-icon" aria-expanded="false">
						<i class="mdi mdi-cart-plus"></i>
						<span class="nav-text">Order List</span>
					</a>
				</li>
                <li><a href="reports.php" class="ai-icon" aria-expanded="false">
						<i class="mdi mdi-chart-bar-stacked"></i>
						<span class="nav-text">Commission Report</span>
					</a>
				</li>
                </ul>
            
			</div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->
		